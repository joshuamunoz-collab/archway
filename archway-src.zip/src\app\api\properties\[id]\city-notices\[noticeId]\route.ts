import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth'

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string; noticeId: string }> }
) {
  const auth = await requireAuth()
  if (auth instanceof NextResponse) return auth

  const { id, noticeId } = await params
  const body = await request.json()

  const data: Record<string, unknown> = {}
  if (body.status !== undefined) {
    data.status = body.status
    if (body.status === 'resolved') data.resolvedDate = new Date()
    if (body.status === 'sent_to_pm') data.sentToPmDate = new Date()
    if (body.status === 'pm_acknowledged') data.pmResponseDate = new Date()
  }
  if (body.noticeType !== undefined) data.noticeType = body.noticeType || null
  if (body.description !== undefined) data.description = body.description
  if (body.deadline !== undefined) data.deadline = body.deadline ? new Date(body.deadline) : null
  if (body.assignedTo !== undefined) data.assignedTo = body.assignedTo || null
  if (body.resolutionNotes !== undefined) data.resolutionNotes = body.resolutionNotes || null

  try {
    const updated = await prisma.cityNotice.update({
      where: { id: noticeId, propertyId: id },
      data,
    })

    await prisma.activityLog.create({
      data: {
        entityType: 'property',
        entityId: id,
        action: 'city_notice_updated',
        details: { noticeId, status: body.status },
        userId: auth.user.id,
      },
    })

    return NextResponse.json(updated)
  } catch {
    return NextResponse.json({ error: 'City notice not found' }, { status: 404 })
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string; noticeId: string }> }
) {
  const auth = await requireAuth()
  if (auth instanceof NextResponse) return auth

  const { id, noticeId } = await params

  try {
    await prisma.cityNotice.delete({ where: { id: noticeId, propertyId: id } })

    await prisma.activityLog.create({
      data: {
        entityType: 'property',
        entityId: id,
        action: 'city_notice_deleted',
        details: { noticeId },
        userId: auth.user.id,
      },
    })

    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'City notice not found' }, { status: 404 })
  }
}
