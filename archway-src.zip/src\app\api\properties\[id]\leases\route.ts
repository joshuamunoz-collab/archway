import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth } from '@/lib/auth'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const auth = await requireAuth()
  if (auth instanceof NextResponse) return auth

  const { id: propertyId } = await params
  const body = await request.json()

  const {
    tenantId,
    startDate,
    endDate,
    contractRent,
    hapAmount,
    tenantCopay,
    utilityAllowance,
    paymentStandard,
    hapContractStart,
    hapContractEnd,
    recertificationDate,
    notes,
  } = body

  if (!tenantId || !startDate || contractRent == null) {
    return NextResponse.json({ error: 'tenantId, startDate, and contractRent are required' }, { status: 400 })
  }

  // Terminate any existing active leases for this property
  await prisma.lease.updateMany({
    where: { propertyId, status: 'active' },
    data: { status: 'terminated' },
  })

  const lease = await prisma.lease.create({
    data: {
      propertyId,
      tenantId,
      startDate: new Date(startDate),
      endDate: endDate ? new Date(endDate) : null,
      contractRent: contractRent,
      hapAmount: hapAmount ?? null,
      tenantCopay: tenantCopay ?? null,
      utilityAllowance: utilityAllowance ?? null,
      paymentStandard: paymentStandard ?? null,
      hapContractStart: hapContractStart ? new Date(hapContractStart) : null,
      hapContractEnd: hapContractEnd ? new Date(hapContractEnd) : null,
      recertificationDate: recertificationDate ? new Date(recertificationDate) : null,
      status: 'active',
      notes: notes || null,
    },
    include: { tenant: true },
  })

  // Update property status to occupied
  await prisma.property.update({
    where: { id: propertyId },
    data: { status: 'occupied', vacantSince: null },
  })

  await prisma.activityLog.create({
    data: {
      entityType: 'property',
      entityId: propertyId,
      action: 'lease_created',
      details: {
        tenantName: `${lease.tenant.firstName} ${lease.tenant.lastName}`,
        startDate,
        contractRent: Number(contractRent),
      },
      userId: auth.user.id,
    },
  })

  // Convert Prisma Decimal fields to numbers for JSON serialization
  const serialized = {
    ...lease,
    contractRent: Number(lease.contractRent),
    hapAmount: lease.hapAmount ? Number(lease.hapAmount) : null,
    tenantCopay: lease.tenantCopay ? Number(lease.tenantCopay) : null,
    utilityAllowance: lease.utilityAllowance ? Number(lease.utilityAllowance) : null,
    paymentStandard: lease.paymentStandard ? Number(lease.paymentStandard) : null,
  }

  return NextResponse.json(serialized, { status: 201 })
}
